#include <stdio.h>
#include <stdlib.h>

#include "Session.h"



int main(int argc, char *argv[]) {
	InfoSessionPtr 	MySession1=NULL, MySession2=NULL;
	

	
	return 0;
}
